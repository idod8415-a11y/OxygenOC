package com.example.oxylauncher

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build

/** Перерисовывает иконки приложений в выбранную форму. */
object IconStyler {
    const val ORIGINAL = 0
    const val CIRCLE = 1
    const val SQUIRCLE = 2
    const val SQUARE = 3
    const val DROP = 4
    const val GLASS = 5

    val names = listOf("Оригинал", "Круг", "Сквиркл", "Квадрат", "Капля", "Стекло")

    fun style(res: Resources, src: Drawable, px: Int, shape: Int): Drawable {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = px.toFloat()
        val path = shapePath(s, shape)

        c.save()
        c.clipPath(path)
        drawLayers(src, c, px, if (shape == GLASS) 215 else 255)
        c.restore()

        if (shape == GLASS) {
            val hp = Paint(Paint.ANTI_ALIAS_FLAG)
            hp.shader = LinearGradient(0f, 0f, 0f, s * 0.6f, 0x99FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
            c.save()
            c.clipPath(path)
            c.drawRect(0f, 0f, s, s, hp)
            c.restore()

            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.style = Paint.Style.STROKE
            sp.strokeWidth = s * 0.03f
            sp.shader = LinearGradient(0f, 0f, s, s, 0xCCFFFFFF.toInt(), 0x33FFFFFF, Shader.TileMode.CLAMP)
            c.drawPath(path, sp)
        }
        return BitmapDrawable(res, bmp)
    }

    private fun shapePath(s: Float, shape: Int): Path {
        val p = Path()
        val r = RectF(0f, 0f, s, s)
        when (shape) {
            CIRCLE -> p.addOval(r, Path.Direction.CW)
            SQUIRCLE, GLASS -> p.addRoundRect(r, s * 0.34f, s * 0.34f, Path.Direction.CW)
            SQUARE -> p.addRoundRect(r, s * 0.12f, s * 0.12f, Path.Direction.CW)
            DROP -> {
                val h = s / 2f
                val k = s * 0.08f
                p.addRoundRect(r, floatArrayOf(h, h, h, h, h, h, k, k), Path.Direction.CW)
            }
            else -> p.addRoundRect(r, s * 0.22f, s * 0.22f, Path.Direction.CW)
        }
        return p
    }

    private fun copyOf(d: Drawable?): Drawable? = d?.constantState?.newDrawable()?.mutate()

    private fun drawLayers(src: Drawable, c: Canvas, px: Int, alpha: Int) {
        if (Build.VERSION.SDK_INT >= 26 && src is AdaptiveIconDrawable) {
            // слои 108dp, видно центральные 72dp: растягиваем на 1.5 размера
            val pad = (px * 0.25f).toInt()
            val bg = copyOf(src.background)
            val fg = copyOf(src.foreground)
            if (bg != null) {
                bg.setBounds(-pad, -pad, px + pad, px + pad)
                bg.alpha = alpha
                bg.draw(c)
            }
            if (fg != null) {
                fg.setBounds(-pad, -pad, px + pad, px + pad)
                fg.draw(c)
            }
        } else {
            val plate = Paint(Paint.ANTI_ALIAS_FLAG)
            plate.color = 0xFF2A2A33.toInt()
            plate.alpha = alpha
            c.drawRect(0f, 0f, px.toFloat(), px.toFloat(), plate)
            val d = copyOf(src) ?: src
            val m = (px * 0.14f).toInt()
            d.setBounds(m, m, px - m, px - m)
            d.draw(c)
        }
    }
}
