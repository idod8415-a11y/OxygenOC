package com.example.oxylauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View

/**
 * «Жидкое стекло»: размытые обои под панелью, яркая насыщенность,
 * блик сверху и светлая кромка по краю.
 */
class GlassDrawable(
    private val view: View,
    private val radius: Float,
    private val tint: Int,
    private val provider: () -> Bitmap?
) : Drawable() {

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fallbackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hlPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val rimPath = Path()
    private val rect = RectF()
    private val rimRect = RectF()
    private val dst = RectF()
    private val loc = IntArray(2)

    init {
        val cm = ColorMatrix()
        cm.setSaturation(1.6f)
        bmpPaint.colorFilter = ColorMatrixColorFilter(cm)
        tintPaint.color = tint
        fallbackPaint.color = 0xCC22222A.toInt()
        rimPaint.style = Paint.Style.STROKE
        rimPaint.strokeWidth = view.resources.displayMetrics.density * 1.3f
    }

    override fun onBoundsChange(b: Rect) {
        rect.set(b)
        clip.reset()
        clip.addRoundRect(rect, radius, radius, Path.Direction.CW)

        hlPaint.shader = LinearGradient(
            0f, b.top.toFloat(), 0f, b.top + b.height() * 0.5f,
            0x55FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )

        val i = rimPaint.strokeWidth / 2f
        rimRect.set(b.left + i, b.top + i, b.right - i, b.bottom - i)
        rimPath.reset()
        val rr = maxOf(0f, radius - i)
        rimPath.addRoundRect(rimRect, rr, rr, Path.Direction.CW)
        rimPaint.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            intArrayOf(0xCCFFFFFF.toInt(), 0x14FFFFFF, 0x80FFFFFF.toInt()),
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        if (bounds.isEmpty) return
        canvas.save()
        canvas.clipPath(clip)
        val bmp = provider()
        if (bmp != null) {
            view.getLocationOnScreen(loc)
            val dm = view.resources.displayMetrics
            dst.set(
                -loc[0].toFloat(),
                -loc[1].toFloat(),
                -loc[0].toFloat() + dm.widthPixels,
                -loc[1].toFloat() + dm.heightPixels
            )
            canvas.drawBitmap(bmp, null, dst, bmpPaint)
        } else {
            canvas.drawRect(rect, fallbackPaint)
        }
        canvas.drawRect(rect, tintPaint)
        canvas.drawRect(rect, hlPaint)
        canvas.restore()
        if (radius > 0f) canvas.drawPath(rimPath, rimPaint)
    }

    override fun setAlpha(alpha: Int) {
        bmpPaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        // фильтр насыщенности задан внутри
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
