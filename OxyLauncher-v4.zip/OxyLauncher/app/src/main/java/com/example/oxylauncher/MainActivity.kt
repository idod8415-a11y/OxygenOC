package com.example.oxylauncher

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.app.WallpaperManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.hypot

data class AppInfo(
    val key: String,
    val pkg: String,
    val label: String,
    val icon: Drawable,
    val launchIntent: Intent,
    val isSystem: Boolean
)

/** from: "page0", "page1", "page2", "dock" или "drawer" */
class DragInfo(val key: String, val from: String, val fromCell: Int)

class MenuItem(val title: String, val action: () -> Unit)

class GlassSpec(val view: View, val radius: Int, val tint: Int, val plain: Int)

class MainActivity : AppCompatActivity() {

    private val pageCount = 3
    private val allApps = mutableListOf<AppInfo>()
    private val byKey = HashMap<String, AppInfo>()
    private val pages = List(pageCount) { HashMap<Int, String>() }
    private val dock = HashMap<Int, String>()
    private lateinit var prefs: SharedPreferences

    private val pageGrids = mutableListOf<CellGrid>()
    private lateinit var pager: PagerHost
    private lateinit var dockGrid: CellGrid
    private lateinit var dots: LinearLayout
    private lateinit var clockBox: View
    private lateinit var homeContent: View
    private lateinit var hint: TextView
    private lateinit var drawer: View
    private lateinit var drawerList: RecyclerView
    private lateinit var search: EditText
    private lateinit var dragBar: View
    private lateinit var editBar: View
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var gestures: GestureDetector

    private var drawerOpen = false
    private var editMode = false
    private var menu: PopupWindow? = null
    private var touchSlop = 0
    private var lastPlacedKey: String? = null
    private var entrance = true

    private var iconShape = 0
    private var iconSize = 1
    private var showLabels = true
    private var glassOn = true
    private var wallId = 0
    private var glassBitmap: Bitmap? = null
    private val iconCache = HashMap<String, Drawable>()
    private val glassSpecs = mutableListOf<GlassSpec>()
    private val iconSizes = intArrayOf(46, 54, 62)
    private lateinit var settingsPanel: ScrollView
    private lateinit var settingsContent: LinearLayout
    private var settingsOpen = false

    private val handler = Handler(Looper.getMainLooper())
    private var edgeDir = 0
    private val edgeRunnable = Runnable {
        val d = edgeDir
        edgeDir = 0
        if (d != 0) pager.setPage(pager.current + d, true)
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            reloadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("layout", MODE_PRIVATE)
        touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        loadStyle()

        pager = findViewById(R.id.pager)
        dockGrid = findViewById(R.id.dockGrid)
        dots = findViewById(R.id.dots)
        clockBox = findViewById(R.id.clockBox)
        homeContent = findViewById(R.id.homeContent)
        hint = findViewById(R.id.hint)
        drawer = findViewById(R.id.drawer)
        drawerList = findViewById(R.id.appGrid)
        search = findViewById(R.id.search)
        dragBar = findViewById(R.id.dragBar)
        editBar = findViewById(R.id.editBar)
        drawer.isClickable = true
        settingsPanel = findViewById(R.id.settingsPanel)
        settingsContent = findViewById(R.id.settingsContent)

        ensureDefaultWallpaper()
        loadGlassBitmap()
        registerGlass(dockGrid, 28, 0x33000000)
        registerGlass(editBar, 20, 0x40000000)
        registerGlass(dragBar, 20, 0x40000000)
        registerGlass(settingsPanel, 26, 0x59000000)
        registerGlass(drawer, 0, 0x73000000, 0xF2101014.toInt())
        registerGlass(search, 24, 0x26000000)

        dockGrid.cols = 4
        dockGrid.rows = 1
        for (i in 0 until pageCount) {
            val grid = CellGrid(this)
            grid.cols = 4
            grid.rows = 5
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            lp.setMargins(dp(8), 0, dp(8), 0)
            pager.addView(grid, lp)
            pageGrids.add(grid)
            grid.setOnDragListener(gridDragListener(grid, pages[i], true))
            grid.setOnLongClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                setEdit(true)
                true
            }
        }
        dockGrid.setOnDragListener(gridDragListener(dockGrid, dock, false))

        pager.onProgress = { p ->
            updateDots(p)
            val k = p.coerceIn(0f, 1f)
            clockBox.alpha = 1f - k
            clockBox.translationX = -k * dp(80)
        }
        buildDots()

        drawerAdapter = AppAdapter { v, app ->
            styleItem(v, app)
            attachBehavior(v, app, "drawer", -1)
        }
        drawerList.layoutManager = GridLayoutManager(this, 4)
        drawerList.adapter = drawerAdapter
        search.doAfterTextChanged { text -> filter(text?.toString().orEmpty()) }

        findViewById<View>(R.id.removeZone).setOnDragListener(zoneListener { info ->
            mapFor(info.from)?.remove(info.fromCell)
        })
        findViewById<View>(R.id.uninstallZone).setOnDragListener(zoneListener { info ->
            byKey[info.key]?.let { uninstall(it) }
        })
        findViewById<View>(R.id.root).setOnDragListener { _, e ->
            when (e.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    dragBar.alpha = 0f
                    dragBar.visibility = View.VISIBLE
                    dragBar.animate().alpha(1f).setDuration(150).start()
                    true
                }
                DragEvent.ACTION_DRAG_ENDED -> {
                    cancelEdge()
                    dragBar.visibility = View.GONE
                    saveAndRender()
                    true
                }
                else -> true
            }
        }

        findViewById<View>(R.id.btnStyle).setOnClickListener { openSettings() }
        findViewById<View>(R.id.btnDone).setOnClickListener { setEdit(false) }

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (e1 == null) return false
                if (settingsOpen) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (abs(dy) < abs(dx)) return false
                if (!drawerOpen && dy < -dp(80) && velocityY < -800) {
                    openDrawer()
                    return true
                }
                if (drawerOpen && dy > dp(80) && velocityY > 800 &&
                    !drawerList.canScrollVertically(-1)
                ) {
                    closeDrawer()
                    return true
                }
                return false
            }
        })

        reloadApps()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: IllegalArgumentException) {
            // уже снят
        }
        dismissMenu()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) {
            dismissMenu()
            if (drawerOpen) closeDrawer()
            setEdit(false)
            pager.setPage(0, true)
        }
    }

    override fun onBackPressed() {
        when {
            menu != null -> dismissMenu()
            settingsOpen -> closeSettings()
            drawerOpen -> closeDrawer()
            editMode -> setEdit(false)
            else -> { /* лаунчер: назад ничего не закрывает */ }
        }
    }

    // ---------- индикатор страниц ----------

    private fun buildDots() {
        dots.removeAllViews()
        for (i in 0 until pageCount) {
            val d = View(this)
            d.background = ContextCompat.getDrawable(this, R.drawable.bg_dot)
            val lp = LinearLayout.LayoutParams(dp(7), dp(7))
            lp.setMargins(dp(4), 0, dp(4), 0)
            dots.addView(d, lp)
        }
        updateDots(0f)
    }

    private fun updateDots(pos: Float) {
        for (i in 0 until dots.childCount) {
            val d = dots.getChildAt(i)
            val k = minOf(1f, abs(i - pos))
            val s = 1.4f - 0.4f * k
            d.scaleX = s
            d.scaleY = s
            d.alpha = 1f - 0.6f * k
        }
    }

    // ---------- данные ----------

    private fun reloadApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(query, 0)

        allApps.clear()
        byKey.clear()
        for (ri in resolved) {
            val pkg = ri.activityInfo.packageName
            if (pkg == packageName) continue
            val cls = ri.activityInfo.name
            val intent = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(pkg, cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val system = (ri.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val app = AppInfo("$pkg/$cls", pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), intent, system)
            allApps.add(app)
            byKey[app.key] = app
        }
        allApps.sortBy { it.label.lowercase() }

        loadLayout()
        if (allApps.isNotEmpty()) {
            if (!prefs.getBoolean("init_v3", false)) {
                if (dock.isEmpty()) buildDefaultDock()
                if (pages.all { it.isEmpty() }) prefillHome()
                prefs.edit().putBoolean("init_v3", true).apply()
            }
            for (p in pages) p.entries.removeAll { !byKey.containsKey(it.value) }
            dock.entries.removeAll { !byKey.containsKey(it.value) }
            saveLayout()
        }
        filter(search.text?.toString().orEmpty())
        render()
    }

    private fun buildDefaultDock() {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        var cell = 0
        for (i in intents) {
            val pkg = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName ?: continue
            val app = allApps.firstOrNull { a -> a.pkg == pkg } ?: continue
            if (dock.values.contains(app.key)) continue
            dock[cell] = app.key
            cell++
        }
    }

    private fun prefillHome() {
        val docked = dock.values.toSet()
        var cell = 0
        for (app in allApps) {
            if (cell >= 12) break
            if (docked.contains(app.key)) continue
            pages[0][cell] = app.key
            cell++
        }
    }

    private fun pageKey(i: Int): String = if (i == 0) "home" else "home$i"

    private fun loadLayout() {
        for (i in 0 until pageCount) {
            pages[i].clear()
            parse(prefs.getString(pageKey(i), "") ?: "", pages[i])
        }
        dock.clear()
        parse(prefs.getString("dock", "") ?: "", dock)
    }

    private fun parse(s: String, m: HashMap<Int, String>) {
        for (line in s.split("\n")) {
            val p = line.split("\t")
            if (p.size == 2) {
                val cell = p[0].toIntOrNull()
                if (cell != null) m[cell] = p[1]
            }
        }
    }

    private fun ser(m: HashMap<Int, String>): String =
        m.entries.joinToString("\n") { "${it.key}\t${it.value}" }

    private fun saveLayout() {
        val e = prefs.edit()
        for (i in 0 until pageCount) e.putString(pageKey(i), ser(pages[i]))
        e.putString("dock", ser(dock))
        e.apply()
    }

    private fun saveAndRender() {
        saveLayout()
        render()
    }

    private fun mapFor(from: String): HashMap<Int, String>? {
        if (from == "dock") return dock
        if (from.startsWith("page")) {
            val i = from.substring(4).toIntOrNull() ?: return null
            if (i in 0 until pageCount) return pages[i]
        }
        return null
    }

    private fun filter(query: String) {
        val q = query.trim().lowercase()
        val list = if (q.isEmpty()) allApps else allApps.filter { it.label.lowercase().contains(q) }
        drawerAdapter.submit(list)
    }

    // ---------- отрисовка ----------

    private var entranceIndex = 0

    private fun render() {
        entranceIndex = 0
        for (i in 0 until pageCount) {
            pageGrids[i].removeAllViews()
            fill(pageGrids[i], pages[i], "page$i")
        }
        dockGrid.removeAllViews()
        fill(dockGrid, dock, "dock")
        hint.visibility = if (pages.all { it.isEmpty() }) View.VISIBLE else View.GONE
        lastPlacedKey = null
        entrance = false
    }

    private fun fill(grid: CellGrid, map: HashMap<Int, String>, from: String) {
        for ((cell, key) in map) {
            val app = byKey[key] ?: continue
            if (cell < 0 || cell >= grid.totalCells) continue
            val v = LayoutInflater.from(this).inflate(R.layout.item_app, grid, false)
            (v as LinearLayout).gravity = Gravity.CENTER
            styleItem(v, app)
            grid.addView(v, CellGrid.Lp(cell))
            attachBehavior(v, app, from, cell)

            if (key == lastPlacedKey) {
                v.scaleX = 0.5f
                v.scaleY = 0.5f
                v.alpha = 0f
                v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(320)
                    .setInterpolator(OvershootInterpolator(2.2f)).start()
            } else if (entrance) {
                v.alpha = 0f
                v.translationY = dp(24).toFloat()
                v.animate().alpha(1f).translationY(0f).setDuration(350)
                    .setStartDelay((entranceIndex * 18L).coerceAtMost(500L))
                    .setInterpolator(DecelerateInterpolator(1.8f)).start()
                entranceIndex++
            }
        }
    }

    // ---------- поведение иконок ----------

    private fun attachBehavior(v: View, app: AppInfo, from: String, cell: Int) {
        var longPressed = false
        var dragging = false
        var downX = 0f
        var downY = 0f

        v.setOnClickListener { launch(it, app) }
        v.setOnLongClickListener {
            longPressed = true
            it.parent?.requestDisallowInterceptTouchEvent(true)
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            showAppMenu(it, app, from, cell)
            true
        }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longPressed = false
                    dragging = false
                    downX = e.rawX
                    downY = e.rawY
                    view.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90)
                        .setInterpolator(DecelerateInterpolator()).start()
                    if (editMode && from != "drawer") {
                        view.parent?.requestDisallowInterceptTouchEvent(true)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (longPressed) view.parent?.requestDisallowInterceptTouchEvent(true)
                    val dist = hypot(e.rawX - downX, e.rawY - downY)
                    val canDrag = longPressed || (editMode && from != "drawer")
                    if (!dragging && canDrag && dist > touchSlop) {
                        dragging = true
                        longPressed = false
                        dismissMenu()
                        startDrag(view, app, from, cell)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220)
                        .setInterpolator(OvershootInterpolator(2f)).start()
                }
            }
            false
        }
    }

    private fun startDrag(v: View, app: AppInfo, from: String, cell: Int) {
        val info = DragInfo(app.key, from, cell)
        val clip = ClipData.newPlainText("app", app.key)
        val started = v.startDragAndDrop(clip, View.DragShadowBuilder(v), info, 0)
        if (started) {
            if (from == "drawer") closeDrawer() else v.visibility = View.INVISIBLE
        }
    }

    private fun handleEdge(x: Float, width: Int) {
        val edge = dp(36)
        val dir = if (x < edge) -1 else if (x > width - edge) 1 else 0
        if (dir == edgeDir) return
        handler.removeCallbacks(edgeRunnable)
        edgeDir = dir
        if (dir != 0) handler.postDelayed(edgeRunnable, 550)
    }

    private fun cancelEdge() {
        handler.removeCallbacks(edgeRunnable)
        edgeDir = 0
    }

    private fun gridDragListener(grid: CellGrid, map: HashMap<Int, String>, edgeScroll: Boolean) =
        View.OnDragListener { _, e ->
            when (e.action) {
                DragEvent.ACTION_DRAG_LOCATION -> {
                    if (edgeScroll) handleEdge(e.x, grid.width) else cancelEdge()
                }
                DragEvent.ACTION_DRAG_EXITED -> cancelEdge()
                DragEvent.ACTION_DROP -> {
                    cancelEdge()
                    val info = e.localState as? DragInfo
                    if (info != null) place(info, map, grid.cellAt(e.x, e.y))
                }
            }
            true
        }

    private fun zoneListener(onDrop: (DragInfo) -> Unit) = View.OnDragListener { _, e ->
        if (e.action == DragEvent.ACTION_DROP) {
            val info = e.localState as? DragInfo
            if (info != null) onDrop(info)
        }
        true
    }

    private fun removeKey(key: String) {
        for (p in pages) p.entries.removeAll { it.value == key }
        dock.entries.removeAll { it.value == key }
    }

    private fun firstFree(map: HashMap<Int, String>, total: Int): Int? =
        (0 until total).firstOrNull { !map.containsKey(it) }

    /** Ищет свободную ячейку, начиная с текущей страницы. */
    private fun placeInFirstFree(key: String): Boolean {
        for (n in 0 until pageCount) {
            val i = (pager.current + n) % pageCount
            val cell = firstFree(pages[i], pageGrids[i].totalCells)
            if (cell != null) {
                pages[i][cell] = key
                return true
            }
        }
        return false
    }

    private fun place(info: DragInfo, dst: HashMap<Int, String>, dstCell: Int) {
        val src = mapFor(info.from)
        if (src === dst && info.fromCell == dstCell) return
        if (src == null) removeKey(info.key) else src.remove(info.fromCell)
        val occupant = dst[dstCell]
        dst[dstCell] = info.key
        lastPlacedKey = info.key
        if (occupant != null && occupant != info.key) {
            if (src != null) src[info.fromCell] = occupant else placeInFirstFree(occupant)
        }
    }

    private fun addToHome(key: String) {
        removeKey(key)
        if (!placeInFirstFree(key)) {
            Toast.makeText(this, "На главном экране нет места", Toast.LENGTH_SHORT).show()
            return
        }
        lastPlacedKey = key
        saveAndRender()
        if (drawerOpen) closeDrawer()
    }

    // ---------- меню как в OxygenOS ----------

    private fun dismissMenu() {
        menu?.dismiss()
        menu = null
    }

    private fun showAppMenu(anchor: View, app: AppInfo, from: String, cell: Int) {
        dismissMenu()
        val items = mutableListOf<MenuItem>()
        if (from == "drawer") {
            items.add(MenuItem("На главный экран") { addToHome(app.key) })
        } else {
            items.add(MenuItem("Убрать с экрана") {
                mapFor(from)?.remove(cell)
                saveAndRender()
            })
        }
        items.add(MenuItem("О приложении") {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                )
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, "Не удалось открыть", Toast.LENGTH_SHORT).show()
            }
        })
        if (!app.isSystem) items.add(MenuItem("Удалить") { uninstall(app) })

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        styleGlass(box, 20, 0x4D000000)
        box.setPadding(dp(6), dp(6), dp(6), dp(6))
        for (item in items) {
            val tv = TextView(this)
            tv.text = item.title
            tv.setTextColor(ContextCompat.getColor(this, R.color.oxy_text))
            tv.textSize = 15f
            tv.setPadding(dp(18), dp(12), dp(18), dp(12))
            tv.setOnClickListener {
                dismissMenu()
                item.action()
            }
            box.addView(tv)
        }
        box.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        var x = loc[0] + anchor.width / 2 - box.measuredWidth / 2
        x = maxOf(dp(8), minOf(x, screenW - box.measuredWidth - dp(8)))
        var y = loc[1] + anchor.height
        var below = true
        if (y + box.measuredHeight > screenH - dp(24)) {
            y = loc[1] - box.measuredHeight
            below = false
        }

        val popup = PopupWindow(box, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.isOutsideTouchable = true
        popup.elevation = dp(8).toFloat()
        popup.setOnDismissListener { if (menu === popup) menu = null }
        popup.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
        menu = popup

        box.alpha = 0f
        box.scaleX = 0.8f
        box.scaleY = 0.8f
        box.pivotX = box.measuredWidth / 2f
        box.pivotY = if (below) 0f else box.measuredHeight.toFloat()
        box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170)
            .setInterpolator(DecelerateInterpolator(1.5f)).start()
    }

    private fun uninstall(app: AppInfo) {
        if (app.isSystem) {
            Toast.makeText(this, "Системное приложение нельзя удалить", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Не удалось удалить", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- режимы и анимации ----------

    private fun setEdit(on: Boolean) {
        if (editMode == on) return
        if (!on && settingsOpen) closeSettings()
        editMode = on
        val s = if (on) 0.88f else 1f
        pager.animate().scaleX(s).scaleY(s).setDuration(260)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
        editBar.animate().cancel()
        if (on) {
            editBar.visibility = View.VISIBLE
            editBar.alpha = 0f
            editBar.translationY = dp(32).toFloat()
            editBar.animate().alpha(1f).translationY(0f).setDuration(260)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        } else {
            editBar.animate().alpha(0f).translationY(dp(32).toFloat()).setDuration(200)
                .setInterpolator(AccelerateInterpolator())
                .withEndAction { if (!editMode) editBar.visibility = View.GONE }
                .start()
        }
    }

    private fun openDrawer() {
        setEdit(false)
        dismissMenu()
        drawerOpen = true
        val h = resources.displayMetrics.heightPixels.toFloat()
        drawer.animate().cancel()
        drawer.visibility = View.VISIBLE
        drawer.alpha = 0f
        drawer.translationY = h * 0.18f
        drawer.animate().alpha(1f).translationY(0f).setDuration(300)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
        homeContent.animate().scaleX(0.94f).scaleY(0.94f).alpha(0.35f).setDuration(300)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    private fun closeDrawer() {
        drawerOpen = false
        val h = resources.displayMetrics.heightPixels.toFloat()
        drawer.animate().alpha(0f).translationY(h * 0.18f).setDuration(240)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
            .start()
        homeContent.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(280)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
        search.setText("")
        search.clearFocus()
        val imm = getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun launch(v: View, app: AppInfo) {
        if (editMode) return
        try {
            val opts = ActivityOptionsCompat.makeScaleUpAnimation(v, 0, 0, v.width, v.height)
            startActivity(app.launchIntent, opts.toBundle())
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- стиль, обои, стекло ----------

    override fun onResume() {
        super.onResume()
        if (wallId < 0) {
            loadGlassBitmap()
            refreshGlass()
        }
    }

    private fun loadStyle() {
        iconShape = prefs.getInt("icon_shape", 0)
        iconSize = prefs.getInt("icon_size", 1)
        showLabels = prefs.getBoolean("labels", true)
        glassOn = prefs.getBoolean("glass", true)
        wallId = prefs.getInt("wall_id", 0)
    }

    private fun saveStyle() {
        prefs.edit()
            .putInt("icon_shape", iconShape)
            .putInt("icon_size", iconSize)
            .putBoolean("labels", showLabels)
            .putBoolean("glass", glassOn)
            .putInt("wall_id", wallId)
            .apply()
    }

    private fun styleItem(v: View, app: AppInfo) {
        val icon = v.findViewById<ImageView>(R.id.icon)
        val label = v.findViewById<TextView>(R.id.label)
        val px = dp(iconSizes[iconSize.coerceIn(0, 2)])
        val lp = icon.layoutParams
        lp.width = px
        lp.height = px
        icon.layoutParams = lp
        icon.setImageDrawable(styledIcon(app, px))
        label.text = app.label
        label.visibility = if (showLabels) View.VISIBLE else View.GONE
    }

    private fun styledIcon(app: AppInfo, px: Int): Drawable {
        if (iconShape == IconStyler.ORIGINAL) return app.icon
        val k = "${app.key}|$iconShape|$px"
        return iconCache.getOrPut(k) { IconStyler.style(resources, app.icon, px, iconShape) }
    }

    private fun restyle() {
        iconCache.clear()
        render()
        drawerAdapter.notifyDataSetChanged()
    }

    private fun registerGlass(view: View, radiusDp: Int, tint: Int, plain: Int = 0xE61E1E24.toInt()) {
        glassSpecs.add(GlassSpec(view, radiusDp, tint, plain))
        styleGlass(view, radiusDp, tint, plain)
    }

    private fun styleGlass(view: View, radiusDp: Int, tint: Int, plain: Int = 0xE61E1E24.toInt()) {
        if (glassOn) {
            view.background = GlassDrawable(view, dp(radiusDp).toFloat(), tint) { glassBitmap }
        } else {
            val g = GradientDrawable()
            g.setColor(plain)
            g.cornerRadius = dp(radiusDp).toFloat()
            view.background = g
        }
    }

    private fun applyGlassStyles() {
        for (s in glassSpecs) styleGlass(s.view, s.radius, s.tint, s.plain)
    }

    private fun refreshGlass() {
        for (s in glassSpecs) s.view.invalidate()
    }

    private fun loadGlassBitmap() {
        val dm = resources.displayMetrics
        val sw = 54
        val sh = (54f * dm.heightPixels / dm.widthPixels).toInt().coerceAtLeast(54)
        val src: Bitmap? = if (wallId >= 0) WallpaperGen.make(wallId, sw, sh) else wallpaperAsBitmap(sw, sh)
        glassBitmap = if (src != null) WallpaperGen.blur(src, 2, 3) else null
    }

    private fun wallpaperAsBitmap(sw: Int, sh: Int): Bitmap? {
        return try {
            val d = WallpaperManager.getInstance(this).peekDrawable() ?: return null
            val dw = d.intrinsicWidth
            val dh = d.intrinsicHeight
            if (dw <= 0 || dh <= 0) return null
            val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val scale = maxOf(sw.toFloat() / dw, sh.toFloat() / dh)
            c.translate((sw - dw * scale) / 2f, (sh - dh * scale) / 2f)
            c.scale(scale, scale)
            d.setBounds(0, 0, dw, dh)
            d.draw(c)
            out
        } catch (e: Exception) {
            null
        }
    }

    private fun ensureDefaultWallpaper() {
        if (!prefs.getBoolean("wall_init", false)) {
            prefs.edit().putBoolean("wall_init", true).apply()
            applyWallpaper(0)
        }
    }

    private fun applyWallpaper(id: Int) {
        wallId = id
        saveStyle()
        loadGlassBitmap()
        refreshGlass()
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val appCtx = applicationContext
        Thread {
            var ok = true
            try {
                val bmp = WallpaperGen.make(id, w, h)
                WallpaperManager.getInstance(appCtx).setBitmap(
                    bmp, null, true,
                    WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                )
                bmp.recycle()
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                if (!ok) Toast.makeText(this, "Не удалось поставить обои", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }

    // ---------- панель оформления ----------

    private fun openSettings() {
        if (settingsOpen) return
        settingsOpen = true
        buildSettings()
        editBar.visibility = View.GONE
        settingsPanel.animate().cancel()
        settingsPanel.visibility = View.VISIBLE
        settingsPanel.alpha = 0f
        settingsPanel.translationY = dp(60).toFloat()
        settingsPanel.animate().alpha(1f).translationY(0f).setDuration(280)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
    }

    private fun closeSettings() {
        if (!settingsOpen) return
        settingsOpen = false
        settingsPanel.animate().alpha(0f).translationY(dp(60).toFloat()).setDuration(200)
            .setInterpolator(AccelerateInterpolator())
            .withEndAction { if (!settingsOpen) settingsPanel.visibility = View.GONE }
            .start()
        if (editMode) editBar.visibility = View.VISIBLE
    }

    private fun chip(text: String, selected: Boolean, onClick: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(Color.WHITE)
        tv.setPadding(dp(16), dp(9), dp(16), dp(9))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(20).toFloat()
        bg.setColor(if (selected) 0xFFFF6B2C.toInt() else 0x33FFFFFF)
        tv.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        tv.layoutParams = lp
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun addTitle(text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 13f
        tv.setTextColor(0xB3FFFFFF.toInt())
        tv.setPadding(dp(4), dp(14), dp(4), dp(4))
        settingsContent.addView(tv)
    }

    private fun section(title: String, options: List<String>, selected: Int, onPick: (Int) -> Unit) {
        addTitle(title)
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        options.forEachIndexed { i, name ->
            row.addView(chip(name, i == selected) {
                onPick(i)
                saveStyle()
                buildSettings()
            })
        }
        hs.addView(row)
        settingsContent.addView(hs)
    }

    private fun buildSettings() {
        settingsContent.removeAllViews()

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "Оформление"
        title.textSize = 20f
        title.setTextColor(Color.WHITE)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(chip("Закрыть", false) { closeSettings() })
        settingsContent.addView(header)

        addTitle("Обои")
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        for (i in WallpaperGen.presets.indices) {
            val iv = ImageView(this)
            iv.setImageBitmap(WallpaperGen.make(i, 54, 96))
            iv.scaleType = ImageView.ScaleType.FIT_XY
            iv.clipToOutline = true
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(12).toFloat())
                }
            }
            val frame = FrameLayout(this)
            frame.setPadding(dp(3), dp(3), dp(3), dp(3))
            if (wallId == i) {
                val sb = GradientDrawable()
                sb.cornerRadius = dp(15).toFloat()
                sb.setStroke(dp(2), Color.WHITE)
                sb.setColor(Color.TRANSPARENT)
                frame.background = sb
            }
            frame.addView(iv, FrameLayout.LayoutParams(dp(64), dp(112)))
            frame.setOnClickListener {
                applyWallpaper(i)
                buildSettings()
            }
            row.addView(frame)
        }
        row.addView(chip("Своё фото…", wallId < 0) {
            wallId = -1
            saveStyle()
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, "Не удалось открыть выбор обоев", Toast.LENGTH_SHORT).show()
            }
            buildSettings()
        })
        hs.addView(row)
        settingsContent.addView(hs)

        section("Форма иконок", IconStyler.names, iconShape) {
            iconShape = it
            restyle()
        }
        section("Размер иконок", listOf("Мелкие", "Средние", "Крупные"), iconSize) {
            iconSize = it
            restyle()
        }
        section("Подписи", listOf("Показывать", "Скрыть"), if (showLabels) 0 else 1) {
            showLabels = it == 0
            restyle()
        }
        section("Жидкое стекло", listOf("Включено", "Выключено"), if (glassOn) 0 else 1) {
            glassOn = it == 0
            applyGlassStyles()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

class AppAdapter(private val bind: (View, AppInfo) -> Unit) :
    RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppInfo> = emptyList()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        bind(holder.itemView, app)
    }
}
