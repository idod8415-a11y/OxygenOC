package com.example.oxylauncher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader

/** Стандартные обои, нарисованные кодом, и размытие для эффекта стекла. */
object WallpaperGen {

    class Blob(val x: Float, val y: Float, val r: Float, val color: Int)
    class Preset(val name: String, val top: Int, val bottom: Int, val blobs: List<Blob>)

    val presets: List<Preset> = listOf(
        Preset(
            "Аврора", 0xFF0B1026.toInt(), 0xFF1B2B4A.toInt(),
            listOf(
                Blob(0.2f, 0.25f, 0.9f, 0xCC7C4DFF.toInt()),
                Blob(0.85f, 0.45f, 0.8f, 0xCC00E5B0.toInt()),
                Blob(0.4f, 0.88f, 0.9f, 0xCC2979FF.toInt())
            )
        ),
        Preset(
            "Закат", 0xFF2B1055.toInt(), 0xFFFF7A59.toInt(),
            listOf(
                Blob(0.8f, 0.2f, 0.8f, 0xCCFF4D79.toInt()),
                Blob(0.2f, 0.7f, 0.9f, 0xCCFFB347.toInt())
            )
        ),
        Preset(
            "Океан", 0xFF03162E.toInt(), 0xFF0A6C8E.toInt(),
            listOf(
                Blob(0.3f, 0.3f, 0.9f, 0xCC00B4D8.toInt()),
                Blob(0.8f, 0.8f, 0.8f, 0xCC48CAE4.toInt())
            )
        ),
        Preset(
            "Сакура", 0xFF3D1E3A.toInt(), 0xFFE98FA9.toInt(),
            listOf(
                Blob(0.2f, 0.2f, 0.8f, 0xCCFFC2D1.toInt()),
                Blob(0.9f, 0.6f, 0.7f, 0xCCB5179E.toInt())
            )
        ),
        Preset(
            "Лес", 0xFF06201A.toInt(), 0xFF2E7D4F.toInt(),
            listOf(
                Blob(0.7f, 0.25f, 0.8f, 0xCC9BE564.toInt()),
                Blob(0.2f, 0.75f, 0.9f, 0xCC00A878.toInt())
            )
        ),
        Preset(
            "Графит", 0xFF0D0D10.toInt(), 0xFF2A2A33.toInt(),
            listOf(
                Blob(0.5f, 0.3f, 0.9f, 0x66FF6B2C.toInt()),
                Blob(0.2f, 0.8f, 0.7f, 0x4D6C5CE7.toInt())
            )
        )
    )

    fun make(id: Int, w: Int, h: Int): Bitmap {
        val p = presets[id.coerceIn(0, presets.size - 1)]
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), p.top, p.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        for (b in p.blobs) {
            paint.shader = RadialGradient(
                b.x * w, b.y * h, b.r * w,
                b.color, b.color and 0x00FFFFFF, Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        }
        return bmp
    }

    /** Простое размытие боксом: картинка маленькая, так что быстро. */
    fun blur(src: Bitmap, radius: Int, passes: Int): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        val tmp = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in 0 until passes) {
            boxPass(px, tmp, w, h, radius, true)
            boxPass(tmp, px, w, h, radius, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private fun boxPass(inp: IntArray, out: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val n = 2 * r + 1
        for (y in 0 until h) {
            for (x in 0 until w) {
                var a = 0
                var rr = 0
                var g = 0
                var b = 0
                for (k in -r..r) {
                    val xx = if (horizontal) (x + k).coerceIn(0, w - 1) else x
                    val yy = if (horizontal) y else (y + k).coerceIn(0, h - 1)
                    val c = inp[yy * w + xx]
                    a += c ushr 24
                    rr += (c shr 16) and 0xFF
                    g += (c shr 8) and 0xFF
                    b += c and 0xFF
                }
                out[y * w + x] = ((a / n) shl 24) or ((rr / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
    }
}
