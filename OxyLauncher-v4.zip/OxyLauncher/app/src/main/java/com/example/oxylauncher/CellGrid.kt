package com.example.oxylauncher

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup

/** Сетка ячеек: каждый ребёнок живёт в ячейке с номером Lp.cell. */
class CellGrid @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ViewGroup(context, attrs) {

    var cols = 4
    var rows = 5

    class Lp(var cell: Int) :
        ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is Lp
    override fun generateDefaultLayoutParams(): ViewGroup.LayoutParams = Lp(0)
    override fun generateLayoutParams(attrs: AttributeSet?): ViewGroup.LayoutParams = Lp(0)
    override fun generateLayoutParams(p: ViewGroup.LayoutParams?): ViewGroup.LayoutParams = Lp(0)

    val totalCells: Int get() = cols * rows

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(w, h)
        val cw = w / cols
        val ch = h / rows
        for (i in 0 until childCount) {
            getChildAt(i).measure(
                MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l) / cols
        val ch = (b - t) / rows
        for (i in 0 until childCount) {
            val child: View = getChildAt(i)
            val lp = child.layoutParams as Lp
            val col = lp.cell % cols
            val row = lp.cell / cols
            child.layout(col * cw, row * ch, (col + 1) * cw, (row + 1) * ch)
        }
    }

    fun cellAt(x: Float, y: Float): Int {
        if (width <= 0 || height <= 0) return 0
        val col = (x / (width / cols)).toInt().coerceIn(0, cols - 1)
        val row = (y / (height / rows)).toInt().coerceIn(0, rows - 1)
        return row * cols + col
    }
}
