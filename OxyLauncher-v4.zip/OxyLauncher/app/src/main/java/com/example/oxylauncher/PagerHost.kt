package com.example.oxylauncher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt

/** Горизонтальный пейджер: страницы едут за пальцем и плавно доезжают. */
class PagerHost @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    var current = 0
        private set
    var onProgress: ((Float) -> Unit)? = null
    var onPageChanged: ((Int) -> Unit)? = null
    var swipeEnabled = true

    private var pos = 0f
    private var downX = 0f
    private var downY = 0f
    private var startPos = 0f
    private var dragging = false
    private var tracker: VelocityTracker? = null
    private var anim: ValueAnimator? = null
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        applyScroll()
    }

    private fun applyScroll() {
        val w = width.toFloat()
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val d = i - pos
            c.translationX = d * w
            c.alpha = 1f - 0.6f * min(1f, abs(d))
        }
        onProgress?.invoke(pos)
    }

    private fun finish(target: Int) {
        if (current != target) {
            current = target
            onPageChanged?.invoke(target)
        }
    }

    fun setPage(page: Int, animate: Boolean = true) {
        val target = page.coerceIn(0, maxOf(0, childCount - 1))
        anim?.cancel()
        if (!animate) {
            pos = target.toFloat()
            finish(target)
            applyScroll()
            return
        }
        val a = ValueAnimator.ofFloat(pos, target.toFloat())
        a.duration = 320
        a.interpolator = DecelerateInterpolator(1.6f)
        a.addUpdateListener {
            pos = it.animatedValue as Float
            applyScroll()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                finish(target)
            }
        })
        anim = a
        a.start()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (!swipeEnabled) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                startPos = pos
                dragging = false
                anim?.cancel()
                tracker?.recycle()
                tracker = VelocityTracker.obtain()
                tracker?.addMovement(ev)
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(ev)
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (!dragging && abs(dx) > slop && abs(dx) > abs(dy) * 1.5f) {
                    dragging = true
                    startPos = pos
                    downX = ev.x
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (!dragging) {
                    tracker?.recycle()
                    tracker = null
                }
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!swipeEnabled) return false
        tracker?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                startPos = pos
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.x - downX
                if (!dragging && abs(dx) > slop) {
                    dragging = true
                    startPos = pos
                    downX = ev.x
                }
                if (dragging && width > 0) {
                    val d = ev.x - downX
                    pos = (startPos - d / width).coerceIn(-0.2f, (childCount - 1) + 0.2f)
                    applyScroll()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    tracker?.computeCurrentVelocity(1000)
                    val vx = tracker?.xVelocity ?: 0f
                    var target = pos.roundToInt()
                    if (vx < -800f) target = floor(pos).toInt() + 1
                    else if (vx > 800f) target = ceil(pos).toInt() - 1
                    setPage(target, true)
                }
                dragging = false
                tracker?.recycle()
                tracker = null
            }
        }
        return true
    }
}
